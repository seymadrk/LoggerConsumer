﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary
{
    public class ErrorModel
    {
        public string Message { get; set; }
        public string Type { get; set; }
    }
}
