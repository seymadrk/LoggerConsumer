﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary
{
    interface ILogger
    {
        string Log(ErrorModel error);
    }
}
