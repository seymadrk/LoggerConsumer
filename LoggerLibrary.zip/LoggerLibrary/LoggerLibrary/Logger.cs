﻿using System;

namespace LoggerLibrary
{
    public class Logger : ILogger
    {
        public string Log(ErrorModel error)
        {
            //Burda bir takım log la işlemleri yapıldığını varsayıyoruz..
            return "Hata başarılı bir şekilde log'landı. Hata: " + error.Message + " " + " Tipi:" + error.Type;
        }
    }
}
