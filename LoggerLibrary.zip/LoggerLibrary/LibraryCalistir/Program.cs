﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoggerLibrary;

namespace LibraryCalistir
{
    class Program
    {
        static void Main(string[] args)
        {
            var model = new ErrorModel() { Message = "Sistem Hatası", Type = "Sistem" };

            Logger logla = new Logger();
            
            var result = logla.Log(model);

            Console.WriteLine(result);
            Console.Read();
        }
    }
}
